﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3_deneme8
{
    class VeriOku
    {
        public int OperatorAl(List<string> Liste, char[] Dizi, int Sayac)
        {
            Liste.Add(Dizi[Sayac].ToString());//Operatorü diziye ekliyoruz
            Sayac++;

            return Sayac;
        }

        public int SayiAl(List<string> Liste, char[] Dizi, int Sayac)
        {
            Liste.Add(Dizi[Sayac].ToString());
            int SonIndex = Liste.LastIndexOf(Dizi[Sayac].ToString());//Son index i tutuyoruz böylece eğer sayı birden fazla basamaklı ise bunların doğru alınıp eklenmesini sağlıyoruz
            Sayac++;
            while ((Sayac <= Dizi.Length - 1) && (Dizi[Sayac] >= 48 && Dizi[Sayac] <= 57))
            {
                Liste[SonIndex] += Dizi[Sayac].ToString();
                Sayac++;
            }
            return Sayac;
        }
    }
}
