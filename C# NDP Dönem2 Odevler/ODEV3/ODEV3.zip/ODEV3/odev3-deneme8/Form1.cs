﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:3
**				ÖĞRENCİ ADI............:Sedanur Ceylan
**				ÖĞRENCİ NUMARASI.......:G130910005
**              DERSİN ALINDIĞI GRUP...:1C
****************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace odev3_deneme8
{
    public partial class Form1 : Form
    {
        VeriOku Veri = new VeriOku();//Verileri almak için oluşturduğumuz classdan bir obje üretiyoruz
        Hesapla Hesap = new Hesapla();//Verileri hesaplamak için oluşturduğumuz classdan bir obje üretiyoruz

        int Sayac = 0;
        char[] Operatorler = { '+', '-', '*', '/' };//Tüm operatorleri tutuğumuz dizi

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Hesapla_Click(object sender, EventArgs e)
        {

            List<string> Liste = new List<string>();//Girilen verileri işlem kolaylığı açısında tutmak için oluşturulmuş liste
            char[] Dizi = Girdi.Text.ToCharArray();//Girilen verileri birlik parçalara ayırarak geçici bir diziye aktarılıyor

            while (true && Girdi.Text != null)//Girdinin kutusunun boş olup olmadığı kontrol ediliyor
            {
                if (Sayac >= Dizi.Length)//Overflow yaşamamak için oluşturulmuş bir ifade
                    break;

                for (int i = 0; i < Operatorler.Length; i++)//Verileri okuyoruz ve operatorleri alıyoruz
                {
                    if ((Sayac < Dizi.Length) && (Dizi[Sayac] == Operatorler[i]))
                    {
                        Sayac = Veri.OperatorAl(Liste, Dizi, Sayac);
                    }
                }

                while ((Sayac <= Dizi.Length - 1) && (Dizi[Sayac] >= 48 && Dizi[Sayac] <= 57))//Verileri okuyoruz ve ascii karakterlerine göre sayıları alıyoruz
                {
                    Sayac = Veri.SayiAl(Liste, Dizi, Sayac);
                }
            }

            while (Liste.Contains("+") || Liste.Contains("-") || Liste.Contains("*") || Liste.Contains("/"))//Liste içinde operator bulunup bulunmamasına göre döngü çalışmakta
            {
                if (Liste.Contains("*") || Liste.Contains("/"))
                {
                    if (Liste.Contains("/"))//Bölme işlemi için gerekli fonksiyon çağırılır
                    {
                        Hesap.Bolme(Liste);
                    }
                    else//Çarpma işlemi için gerekli fonksiyon çağırılır
                    {
                        Hesap.Carpma(Liste);
                    }
                }
                else
                {
                    if (Liste.Contains("-"))//Çıkarma işlemi için gerekli fonksiyon çağırılır
                    {
                        Hesap.Cikarma(Liste);
                    }
                    else//Toplama işlemi için gerekli fonksiyon çağırılır
                    {
                        Hesap.Toplama(Liste);
                    }
                }
            }
            Cikti.Text = Liste[0];//Sonucu ekrana bastırıyoruz
            Sayac = 0;//Yeni bir eşitlik girildiğinde çalışabilmesi için sayaç değişkeni sıfırlanır
        }
    }
}
