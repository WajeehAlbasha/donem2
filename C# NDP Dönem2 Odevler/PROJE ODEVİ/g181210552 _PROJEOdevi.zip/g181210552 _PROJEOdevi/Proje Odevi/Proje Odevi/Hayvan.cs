﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje_Odevi
{
    abstract class Hayvan
    {
        public int enerjiTuketimi;
        public int urunSuresi;
        public int urunUcreti;
        public int tamEnerji;
        public int enerji;
        public bool hayvanDurum;
    }
}
