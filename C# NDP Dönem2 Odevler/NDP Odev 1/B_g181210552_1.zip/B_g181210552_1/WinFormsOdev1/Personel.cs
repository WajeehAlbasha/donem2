﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;



namespace WinFormsOdev1
{
    class Personel
    {
        public string tc;
        public string adi;
        public string soyadi;
        public int yas;
        public int calismaSuresi;
        public string evlilikDurumu;
        public string esCalismaDurumu;
        public int cocukSayisi;
        public int tabanMaas;
        public int makamTazmiati;
        public int idariGorevTazminati;
        public int fazlaMesaiSaati;
        public int fazlaMesaiSaatUcreti;
        public int vergiMatrahi;
        public int brutMaas;
        public int damgaVergisi;
        public int gelirVergisi;
        public int emekliKesintisi;
        public int netMaas;
        

    }
}
