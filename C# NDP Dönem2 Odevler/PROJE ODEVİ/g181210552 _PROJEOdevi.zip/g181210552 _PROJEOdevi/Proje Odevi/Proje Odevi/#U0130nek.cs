﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje_Odevi
{
    class İnek : Hayvan,Ises
    {
        public İnek()
        {
            enerjiTuketimi = 8;
            urunSuresi = 8;
            urunUcreti = 5;
            tamEnerji = 100;
            enerji=100;
        }
       

        public bool OlunceSesVer()
        {
            if (this.enerji == 0)
            {
                return this.hayvanDurum = false;
            }
            else return this.hayvanDurum = true;
        }




        //public int enerji;
        //public bool hayvanDurumu;

        //public void enerjiAzalt()
        //{
        //    tamEnerji = tamEnerji - enerjiTuketimi;
        //}

        //public void yemVer()
        //{
        //    enerji = 100;

        //}

    }
}
