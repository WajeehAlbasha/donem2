﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Forvet : Futbolcu
    {
        private double Bitiricilik;
        private double IlkDokunus;
        private double Kafa;
        private double OzelYetenek;
        private double SogukKanlilik;
        public Forvet(string AdSoyad, int FormaNo) : base(AdSoyad, FormaNo)
        {
            Random rastgele = new Random();
            this.Bitiricilik = rastgele.Next(70, 100);
            this.IlkDokunus = rastgele.Next(70, 100);
            this.Kafa = rastgele.Next(70, 100);
            this.OzelYetenek = rastgele.Next(70, 100);
            this.SogukKanlilik = rastgele.Next(70, 100);


        }
        public override bool PasVer()
        {
            this.PasSkor = Pas * 0.3 + Yetenek * 0.2 + OzelYetenek * 0.2 + Dayaniklik * 0.1 + DogalForm * 0.1 + Sans * 0.1;
            if (this.PasSkor > 60)
            {
                return true;
            }
            else return false;
        }
        public override bool GolVurusu()
        {
            this.GolSkor = Yetenek * 0.2 + OzelYetenek * 0.2 + Sut * 0.1 + Kafa * 0.1 + IlkDokunus * 0.1 + Bitiricilik * 0.1 + SogukKanlilik * 0.1 + Kararlik * 0.1 + DogalForm * 0.1 + Sans * 0.1;
            if (this.GolSkor > 70)
            {
                return true;
            }
            else return false;
        }
    }
}
