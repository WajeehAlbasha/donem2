﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2018-2019 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........: 2 
**				ÖĞRENCİ ADI............: WAJEEH BACHA
**				ÖĞRENCİ NUMARASI.......: G181210552
**              DERSİN ALINDIĞI GRUP...: B
****************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Futbolcu> takim = new List<Futbolcu>();

            takim.Add(new Defans("Samuel Umtiti", 1));
            takim.Add(new Defans("Pique", 2));
            takim.Add(new Defans("Jordi Alba", 3));
            takim.Add(new Defans("Roberto", 4));
            takim.Add(new OrtaSaha("Sergio Busquets", 5));
            takim.Add(new OrtaSaha("Arthur", 6));           
            takim.Add(new OrtaSaha("Philippe Coutinho", 7));
            takim.Add(new OrtaSaha("Ivan Rakitic", 8));
            takim.Add(new Forvet("Luis Suarez", 9));
            takim.Add(new Forvet("Lionel Messi", 10));
            


            Random rastgele = new Random();
            int i = rastgele.Next(1, 10);
            for (int j = 1; j <= 4; j++)
            {
                if(j==1)
                {
                    int gecici = 0;
                    gecici = i;
                    while (gecici == i)
                    {
                        i = rastgele.Next(1, 10);
                    }
                    if (takim[i].PasVer())
                    {
                        Console.WriteLine(takim[i].adSoyad + "  " + takim[i].formaNo + " oynu baslatti ve basarili pas atti");
                    }
                    else Console.WriteLine("basarisiz pas...");
                }
                if (j == 2)
                {
                    int gecici = 0;
                    gecici = i;
                    while (gecici == i)
                    {
                        i = rastgele.Next(1, 10);
                    }
                    if (takim[i].PasVer())
                    {
                        Console.WriteLine(takim[i].adSoyad + "  " + takim[i].formaNo + " basarili pas atti");
                    }
                    else Console.WriteLine("basarisiz pas...");
                }
                if (j == 3)
                {
                    int gecici = 0;
                    gecici = i;
                    while (gecici == i)
                    {
                        i = rastgele.Next(1, 10);
                    }
                    if (takim[i].PasVer())
                    {
                        Console.WriteLine(takim[i].adSoyad + "  " + takim[i].formaNo + " basarili pas atti");
                    }
                    else Console.WriteLine("basarisiz pas...");
                }
                if (j == 4)
                {
                    int gecici = 0;
                    gecici = i;
                    while (gecici == i)
                    {
                        i = rastgele.Next(1, 10);
                    }
                    if (takim[i].GolVurusu())
                    {
                        Console.WriteLine(takim[i].adSoyad + "  " + takim[i].formaNo + " pas aldi ve GOOOOOL ");
                    }
                    else Console.WriteLine(takim[i].adSoyad + "  " + takim[i].formaNo + " Golu kacirdi :(");
                }
            }
            
        }        
    }    
}
