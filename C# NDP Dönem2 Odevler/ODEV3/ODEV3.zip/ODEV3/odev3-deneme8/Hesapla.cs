﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3_deneme8
{
    class Hesapla
    {
        int BolumPozisyonu;
        int CarpimPozisyonu;
        int CikarmaPozisyonu;
        int ToplamPozisyonu;     

        public void Bolme(List<string> Liste)
        {
            BolumPozisyonu = Liste.IndexOf("/");//Listede ki ilk bölme işleminin indisini alır bu sayede işlemlerimizi bu indise göre doğru hesaplayabiliyoruz
            Liste[BolumPozisyonu] = (Convert.ToDouble(Liste[BolumPozisyonu - 1]) / Convert.ToDouble(Liste[BolumPozisyonu + 1])).ToString();//Bölme işaretinin bir fazla ve eksiğini işleme tabi tutuyoruz ve sonucu bölme işaretinin konumuna koyuyoruz
            Liste.RemoveAt(BolumPozisyonu + 1);//bölen sayıyı atıyoruz
            Liste.RemoveAt(BolumPozisyonu - 1);//bölünen sayıyı atıyoruz
        }
        public void Carpma(List<string> Liste)
        {
            CarpimPozisyonu = Liste.IndexOf("*");//Listede ki ilk çarpma işleminin indisini alarak bu sayede işlemlerimizi bu indise göre doğru hesaplayabiliyoruz
            Liste[CarpimPozisyonu] = (Convert.ToDouble(Liste[CarpimPozisyonu - 1]) * Convert.ToDouble(Liste[CarpimPozisyonu + 1])).ToString();//çarpma işaretinin bir fazla ve eksiğini işleme tabi tutuyoruz ve sonucu çarpma işaretinin konumuna koyuyoruz
            Liste.RemoveAt(CarpimPozisyonu + 1);//ikinci sayıyı atıyoruz
            Liste.RemoveAt(CarpimPozisyonu - 1);//birinci sayıyı atıyoruz
        }
        public void Cikarma(List<string> Liste)
        {
            CikarmaPozisyonu = Liste.IndexOf("-");//Listede ki ilk çıkarma işleminin indisini alır bu sayede işlemlerimizi bu indise göre doğru hesaplarız
            Liste[CikarmaPozisyonu] = "+";//çıkarma işleminden kurtulmak için işlemi artıya çeviririz
            Liste[CikarmaPozisyonu + 1] = (Convert.ToDouble(Liste[CikarmaPozisyonu + 1]) * (-1)).ToString();//sayıyı da negatif sayı olarak alırız
        }
        public void Toplama(List<string> Liste)
        {
            ToplamPozisyonu = Liste.IndexOf("+");//Listede ki ilk toplama işleminin indisini alır bu sayede işlemlerimizi bu indise göre doğru hesaplarız
            Liste[ToplamPozisyonu] = (Convert.ToDouble(Liste[ToplamPozisyonu - 1]) + Convert.ToDouble(Liste[ToplamPozisyonu + 1])).ToString();//toplama işaretinin bir fazla ve eksiğini işleme tabi tutuyoruz ve sonucu toplama işaretinin konumuna koyuyoruz
            Liste.RemoveAt(ToplamPozisyonu + 1);//ikinci sayıyı atıyoruz
            Liste.RemoveAt(ToplamPozisyonu - 1);//birinci sayıyı atıyoruz
        }
    }
}
