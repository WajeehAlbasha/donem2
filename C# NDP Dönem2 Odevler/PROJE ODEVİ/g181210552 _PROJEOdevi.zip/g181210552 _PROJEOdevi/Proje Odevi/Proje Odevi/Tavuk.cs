﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje_Odevi
{
    class Tavuk:Hayvan,Ises
    {
        public Tavuk()
        {
            enerjiTuketimi = 2;
            urunSuresi = 3;
            urunUcreti = 1;
            tamEnerji = 100;
            enerji = 100;
        }
        public bool OlunceSesVer()
        {
            if (this.enerji == 0)
            {
                return this.hayvanDurum = false;
            }
            else return this.hayvanDurum = true;
        }
    }
}
