﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Proje_Odevi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int saniye ;
        int saniye2;
        int saniye3;
        int saniye4;
        int saniye5;
        int saniye6;
        int saniye7;
        int saniye8;
        int saniye9;
        private void Form1_Load(object sender, EventArgs e)
        {        
            timer1.Interval = 1000;
            timer1.Start();
            timer2.Interval = 1000;
            timer2.Start();
            timer3.Interval = 1000;
            timer3.Start();
            timer4.Interval = 1000;
            timer4.Start();
            timer5.Interval = 1000;
            timer5.Start();
            timer6.Interval = 1000;
            timer6.Start();
            timer7.Interval = 1000;
            timer7.Start();
            timer8.Interval = 1000;
            timer8.Start();
            timer9.Interval = 1000;
            timer9.Start();

           

        }
        Tavuk t = new Tavuk();
        Ordek o = new Ordek();
        İnek i = new İnek();
        Keci k = new Keci();
            
        private void button3_Click(object sender, EventArgs e)
        {
            saniye2 = 0;
            progressBar4.Value = t.tamEnerji;            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            saniye4 = 0;
            progressBar2.Value = i.tamEnerji;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            saniye3 = 0;
            progressBar3.Value = o.tamEnerji;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saniye5 = 0;
            progressBar1.Value = k.tamEnerji;
        }

        
        private void timer1_Tick(object sender, EventArgs e)
        {
            saniye++;
            label12.Text = Convert.ToString(saniye + "  SN");
        }
        
        private void timer2_Tick(object sender, EventArgs e)
        {
            saniye2++;
            t.enerji = t.tamEnerji - (saniye2 * t.enerjiTuketimi);
            progressBar4.Value = t.enerji;

            if (progressBar4.Value == 0)
            {
                timer2.Stop();
                t.enerji = 0;
                progressBar4.Value = t.enerji;
            }
            t.OlunceSesVer();
            if (t.hayvanDurum == true)
            {
                label20.Text = Convert.ToString("CANLI");
            }
            else
            {
                label20.Text = Convert.ToString("ÖLDÜ");
                SoundPlayer splayer1 = new SoundPlayer(@"C:\Users\lenovo\source\repos\Proje Odevi\Proje Odevi\Hayvan\tavuk.wav");
                splayer1.Play();
            }
            if (t.enerji == 0) 
            {
                button3.Enabled = false;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            saniye3++;
            o.enerji = o.tamEnerji - (saniye3 * o.enerjiTuketimi);
            progressBar3.Value = o.enerji;

            if (progressBar3.Value <= 1)
            {
                timer3.Stop();
                o.enerji = 0;
                progressBar3.Value = o.enerji;
            }
            o.OlunceSesVer();
            if (o.hayvanDurum == true)
            {
                label19.Text = Convert.ToString("CANLI");
            }
            else
            {
                label19.Text = Convert.ToString("ÖLDÜ");
                SoundPlayer splayer1 = new SoundPlayer(@"C:\Users\lenovo\source\repos\Proje Odevi\Proje Odevi\Hayvan\ordek.wav");
                splayer1.Play();
            }          
            if (o.enerji == 0)
            {
                button4.Enabled = false;
            }
        }
        
        private void timer4_Tick(object sender, EventArgs e)
        {
            saniye4++; 
            i.enerji = i.tamEnerji - (saniye4 * i.enerjiTuketimi);
            progressBar2.Value = i.enerji;
           
            if (progressBar2.Value<=4)
            {
                timer4.Stop();
                i.enerji = 0;
                progressBar2.Value = i.enerji;                
            }
            i.OlunceSesVer();
            if(i.hayvanDurum==true)
            {
                label18.Text = Convert.ToString("CANLI");
            }
            else 
            {
                label18.Text = Convert.ToString("ÖLDÜ");
                SoundPlayer splayer1 = new SoundPlayer(@"C:\Users\lenovo\source\repos\Proje Odevi\Proje Odevi\Hayvan\inek.wav");
                splayer1.Play();
            }
            if (i.enerji==0)
            {
                button1.Enabled = false;                
            }      
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            saniye5++;
            k.enerji = k.tamEnerji - (saniye5 * k.enerjiTuketimi);
            progressBar1.Value = k.enerji;

            if (progressBar1.Value <= 4)
            {
                timer5.Stop();
                k.enerji = 0;
                progressBar1.Value = k.enerji;
            }
            k.OlunceSesVer();
            if (k.hayvanDurum == true)
            {
                label17.Text = Convert.ToString("CANLI");
            }
            else
            {
                label17.Text = Convert.ToString("ÖLDÜ");
                SoundPlayer splayer1 = new SoundPlayer(@"C:\Users\lenovo\source\repos\Proje Odevi\Proje Odevi\Hayvan\keci.wav");
                splayer1.Play();
            }
           
            if (k.enerji==0)
            {
                button2.Enabled = false;
            }
        }
       
        private void timer6_Tick(object sender, EventArgs e)
        {
            saniye6++;
            label15.Text = Convert.ToString(saniye6 / i.urunSuresi + "  KG");
            if (i.enerji==0)
            {
                timer6.Stop();
            }
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            saniye7++;
            label13.Text = Convert.ToString(saniye7 / k.urunSuresi + "  KG");
            if (k.enerji==0)
            {
                timer7.Stop();
            }
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            saniye8++;
            label16.Text = Convert.ToString(saniye8 / t.urunSuresi + "  ADET");
            if (t.enerji == 0)
            {
                timer8.Stop();
            }
        }

        private void timer9_Tick(object sender, EventArgs e)
        {
            saniye9++;
            label14.Text = Convert.ToString(saniye9 / o.urunSuresi + "  ADET");
            if (o.enerji == 0)
            {
                timer9.Stop();
            }
        }
        int toplam;
        private void button8_Click(object sender, EventArgs e)
        {
            toplam += (saniye8 / t.urunSuresi)*t.urunUcreti; 
            saniye8 = 0;
            label11.Text = Convert.ToString(toplam+"  TL");
            if (t.enerji==0)
            {
                label16.Text = "0  ADET";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            toplam += (saniye9 / o.urunSuresi) * o.urunUcreti;
            saniye9 = 0;
            label11.Text = Convert.ToString(toplam+"  TL");
            if (o.enerji == 0) 
            {
                label14.Text = "0 ADET";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            toplam += (saniye6 / i.urunSuresi) * i.urunUcreti;
            saniye6 = 0;
            label11.Text = Convert.ToString(toplam + "  TL");
            if (i.enerji == 0)
            {
                label15.Text = "0 KG";          
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            toplam += (saniye7 / k.urunSuresi) * k.urunUcreti;
            saniye7 = 0;
            label11.Text = Convert.ToString(toplam + "  TL");
            if (k.enerji == 0)
            {
                label13.Text = "0 KG";
            }
        }
    }
}
