﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class Futbolcu
    {
        protected string AdSoyad;
        protected int FormaNo;
        protected double Hiz;
        protected double Dayaniklik;
        protected double Pas;
        protected double Sut;
        protected double Yetenek;
        protected double Kararlik;
        protected double DogalForm;
        protected double Sans;
        protected double GolSkor;
        protected double PasSkor;


        public Futbolcu(string AdSoyad, int FormaNo)
        {
            Random rastgele = new Random();
            this.AdSoyad = AdSoyad;
            this.FormaNo = FormaNo;
            this.Hiz = rastgele.Next(50, 100);
            this.Dayaniklik = rastgele.Next(50, 100);
            this.Pas = rastgele.Next(50, 100);
            this.Sut = rastgele.Next(50, 100);
            this.Yetenek = rastgele.Next(50, 100);
            this.Kararlik = rastgele.Next(50, 100);
            this.DogalForm = rastgele.Next(50, 100);
            this.Sans = rastgele.Next(50, 100);


        }
        public string adSoyad { get { return AdSoyad; } }
        public double formaNo { get { return FormaNo; } }
        public virtual bool PasVer()
        {
            this.PasSkor = Pas * 0.3 + Yetenek * 0.3 + Dayaniklik * 0.1 + DogalForm * 0.1 +
                        Sans * 0.2;
            if (this.PasSkor > 60)
            {
                return true;
            }
            else return false;

        }
        public virtual bool GolVurusu()
        {
            this.GolSkor = GolSkor = Yetenek * 0.3 + Sut * 0.2 + Kararlik * 0.1 + DogalForm * 0.1 +
            Hiz * 0.1 + Sans * 0.2;
            if (this.GolSkor > 70)
            {
                return true;
            }
            else return false;
        }
        public int formano;

    }
}
