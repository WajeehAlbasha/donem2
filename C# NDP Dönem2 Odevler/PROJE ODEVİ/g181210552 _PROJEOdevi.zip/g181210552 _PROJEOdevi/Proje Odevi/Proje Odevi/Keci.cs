﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje_Odevi
{
    class Keci : Hayvan,Ises
    {       
        public Keci()
        {
            enerjiTuketimi = 6;
            urunSuresi = 7;
            urunUcreti = 8;
            tamEnerji = 100;
            enerji = 100;
        }
        public bool OlunceSesVer()
        {
            if (this.enerji == 0)
            {
                return this.hayvanDurum = false;
            }
            else return this.hayvanDurum = true;
        }
    }
}
