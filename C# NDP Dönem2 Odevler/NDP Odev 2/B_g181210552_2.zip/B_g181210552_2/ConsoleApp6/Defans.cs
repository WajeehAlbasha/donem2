﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Defans : Futbolcu
    {
        private double PozisyonAlma;
        private double Kafa;
        private double Sicrama;
        public Defans(string AdSoyad, int FormaNo) : base(AdSoyad, FormaNo)
        {
            Random rastgele = new Random();
            this.PozisyonAlma = rastgele.Next(50, 90);
            this.Kafa = rastgele.Next(50, 90);
            this.Sicrama = rastgele.Next(50, 90);


        }
        public override bool PasVer()
        {
            this.PasSkor = Pas * 0.3 + Yetenek * 0.3 + Dayaniklik * 0.1 + DogalForm * 0.1 + PozisyonAlma * 0.1 + Sans * 0.2;
            if (this.PasSkor > 60)
            {
                return true;
            }
            else return false;
        }
        public override bool GolVurusu()
        {
            this.GolSkor = Yetenek * 0.3 + Sut * 0.2 + Kararlik * 0.1 + DogalForm * 0.1 + Kafa * 0.1 + Sicrama * 0.1 + Sans * 0.1;
            if (this.GolSkor > 70)
            {
                return true;
            }
            else return false;
        }
    }
}
