﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2018-2019 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:1
**				ÖĞRENCİ ADI............:Wajeeh Bacha
**				ÖĞRENCİ NUMARASI.......:G181210552
**              DERSİN ALINDIĞI GRUP...:B
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinFormsOdev1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)//Dosya seçip richTextBox'a atama
        {
            
            OpenFileDialog openFile = new OpenFileDialog();
            Stream myStream;
            string fileName = null;
            string fileText = null;

            if (openFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if ((myStream = openFile.OpenFile()) != null)
                {
                    fileName = openFile.FileName;
                    fileText = File.ReadAllText(fileName);
                    richTextBox3.Text = richTextBox3.Text + fileText;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string hepsi = richTextBox3.Text;
            string[] satirlar = hepsi.Split('\n'); //dosya satırlara ayrılabilir
            string[] kelimeler = hepsi.Split(' ', '\n');//dosya kelimelere ayrılabilir


            Personel[] personeller = new Personel[satirlar.Length - 1];
            int sayi = 0;

            for (int i = 0; i < satirlar.Length - 1; i++)//bilgileri kelimeler dizisine atamaya yarayan döngü
            {
                personeller[i] = new Personel();
                personeller[i].tc = kelimeler[sayi];
                personeller[i].adi = kelimeler[sayi + 1];
                personeller[i].soyadi = kelimeler[sayi + 2];
                personeller[i].yas = Convert.ToUInt16(kelimeler[sayi + 3]);
                personeller[i].calismaSuresi = Convert.ToUInt16(kelimeler[sayi + 4]);
                personeller[i].evlilikDurumu = kelimeler[sayi + 5];
                personeller[i].esCalismaDurumu = kelimeler[sayi + 6];
                personeller[i].cocukSayisi = Convert.ToUInt16(kelimeler[sayi + 7]);
                personeller[i].tabanMaas = Convert.ToUInt16(kelimeler[sayi + 8]);
                personeller[i].makamTazmiati = Convert.ToUInt16(kelimeler[sayi + 9]);
                personeller[i].idariGorevTazminati = Convert.ToUInt16(kelimeler[sayi + 10]);
                personeller[i].fazlaMesaiSaati = Convert.ToUInt16(kelimeler[sayi + 11]);
                personeller[i].fazlaMesaiSaatUcreti = Convert.ToUInt16(kelimeler[sayi + 12]);
                personeller[i].vergiMatrahi = Convert.ToUInt16(kelimeler[sayi + 13]);

                sayi += 14;

               
                if (personeller[i].evlilikDurumu == "B")//evlilik durumunu kontrol edilip maaş hesaplar
                {
                    personeller[i].brutMaas = personeller[i].tabanMaas + personeller[i].makamTazmiati + personeller[i].idariGorevTazminati + (personeller[i].cocukSayisi * 30) + (personeller[i].fazlaMesaiSaati * personeller[i].fazlaMesaiSaatUcreti);
                }

                else if (personeller[i].evlilikDurumu == "E" && personeller[i].esCalismaDurumu == "E")
                {
                    personeller[i].brutMaas = personeller[i].tabanMaas + personeller[i].makamTazmiati + personeller[i].idariGorevTazminati + (personeller[i].cocukSayisi * 30) + (personeller[i].fazlaMesaiSaati * personeller[i].fazlaMesaiSaatUcreti);
                }

                else if (personeller[i].evlilikDurumu == "E" && personeller[i].esCalismaDurumu == "H")
                {
                    personeller[i].brutMaas = personeller[i].tabanMaas + personeller[i].makamTazmiati + personeller[i].idariGorevTazminati + 200 + (personeller[i].cocukSayisi * 30) + (personeller[i].fazlaMesaiSaati * personeller[i].fazlaMesaiSaatUcreti);
                }


                personeller[i].damgaVergisi = (personeller[i].brutMaas * 10) / 100;//Damga vergisi hesaplar


                if (personeller[i].vergiMatrahi < 1000)//vergi matrahına göre gelir vergisi hesaplar
                {
                    personeller[i].gelirVergisi = (personeller[i].brutMaas * 15) / 100;
                }

                if (personeller[i].vergiMatrahi >= 1000 && personeller[i].vergiMatrahi < 2000)
                {
                    personeller[i].gelirVergisi = (personeller[i].brutMaas * 20) / 100;
                }

                else if (personeller[i].vergiMatrahi >= 2000 && personeller[i].vergiMatrahi < 3000)
                {
                    personeller[i].gelirVergisi = (personeller[i].brutMaas * 25) / 100;
                }

                else if (personeller[i].vergiMatrahi >= 3000)
                {
                    personeller[i].gelirVergisi = (personeller[i].brutMaas * 30) / 100;
                }


                personeller[i].emekliKesintisi = (personeller[i].brutMaas * 15) / 100;//emekli kesintisini hesaplar


                personeller[i].netMaas = personeller[i].brutMaas - (personeller[i].emekliKesintisi + personeller[i].gelirVergisi + personeller[i].damgaVergisi);
                
                    if (richTextBox2.Text == personeller[i].tc)// TC ile arama yapıp bilgileri richTextBox'a yazar
                    {
                        richTextBox4.Text = "tc: " + personeller[i].tc + "\n" + "adi: " + personeller[i].adi + "\n" + "soyadi: " + personeller[i].soyadi + "\n" + "Net Maaş: " + personeller[i].netMaas;
                    }

                

            }
            if (richTextBox4.Text == "")
            {
                MessageBox.Show("Aradığınız TC Bulunmadı");//TC bulunmadıysa ekrana mesaj gönderir

            }


        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
